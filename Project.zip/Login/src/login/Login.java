package login;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.logging.*;
import javax.swing.*;

public class Login extends JFrame {

    JFrame w, fn;
    JLabel jl, j1, j2, jln1, jln2, jln3;
    JTextField tf;
    JPasswordField pf;
    String st;

    Login() {
        File file = new File("a.txt");
        st = file.getAbsolutePath();

        w = new JFrame();

        fn = new JFrame();

        jl = new JLabel();
        jl.setText("Club Member Login");
        jl.setBounds(170, 100, 400, 50);

        j1 = new JLabel();
        j1.setText("Name");
        j1.setBounds(120, 150, 50, 50);

        j2 = new JLabel();
        j2.setText("Password");
        j2.setBounds(100, 200, 100, 50);

        tf = new JTextField();
        tf.setBounds(170, 150, 200, 40);
        pf = new JPasswordField();
        pf.setBounds(170, 200, 200, 40);

        JButton b = new JButton("Login");
        b.setBounds(150, 300, 70, 40);
        JButton c = new JButton("Create a new account");
        c.setBounds(240, 300, 200, 40);
        
        JButton back= new JButton("Back");
        back.setBounds(230, 250, 70, 30);
        fn.add(back);
        
        
        JButton d = new JButton("Enter");
        d.setBounds(170, 300, 200, 40);

        w.add(tf);
        w.add(pf);
        w.add(jl);
        w.add(j1);
        w.add(j2);
        w.add(b);
        w.add(c);

        w.setSize(500, 500);
        w.setLayout(null);

        w.setVisible(true);

        jln1 = new JLabel();
        jln1.setText("New Account");
        jln1.setBounds(170, 100, 100, 50);

        jln2 = new JLabel();
        jln2.setText("Enter Name");
        jln2.setBounds(100, 150, 100, 50);

        jln3 = new JLabel();
        jln3.setText("Enter Password");
        jln3.setBounds(70, 190, 100, 50);

        JTextField tf1 = new JTextField();
        JPasswordField df1 = new JPasswordField();
        tf1.setBounds(170, 150, 200, 40);
        df1.setBounds(170, 200, 200, 40);
        

        fn.add(jln1);
        fn.add(jln2);
        fn.add(jln3);
        fn.add(tf1);
        fn.add(df1);

        fn.add(d);

        fn.setSize(500, 500);
        fn.setLayout(null);

        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {

                    Scanner input = new Scanner(file);
                    String userName = input.nextLine();
                    String userPassword = input.nextLine();
                    if (file.exists()) {
                        if (tf.getText().isEmpty() && pf.getPassword().length == 0) {
                            JOptionPane.showMessageDialog(null, "You cannot leave the boxes blank!");
                        } else if (userName.equals(tf.getText()) && userPassword.equals(new String(pf.getPassword()))) {
                            w.setVisible(false);

                            new Information();

                        } else {
                            JOptionPane.showMessageDialog(null, "Wrong Info! If you do not have any account, create one!");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Create an account first!");
                    }

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Create an account first!");

                }

            }
        });
        c.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                w.setVisible(false);
                fn.setVisible(true);

            }

        });
        d.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {
                    if (tf1.getText().length() > 4 && df1.getPassword().length > 6) {
                        PrintWriter pw = new PrintWriter(st);
                        pw.print(tf1.getText());
                        pw.println();
                        pw.print(df1.getPassword());
                        pw.flush();

                        pw.close();
                        JOptionPane.showMessageDialog(null, "Your account has been created!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Letters must be greater than 6!");
                    }
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        back.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                //new Information();
                new Login();
                fn.setVisible(false);
            }
        });

    }

    public static void main(String[] args) {
        new Login();
    }

}
