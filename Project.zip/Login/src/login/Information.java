/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author HP
 */
public class Information extends JFrame {

    JFrame a1, b1;

    Information() {

        a1 = new JFrame();

        b1 = new JFrame();

        JButton b = new JButton("Notice");
        b.setBounds(150, 300, 70, 40);

        JButton c = new JButton("UPComing Events");
        c.setBounds(240, 300, 200, 40);

        add(b);
        add(c);
        setSize(600, 600);
        setLayout(null);
        setVisible(true);

        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                new Notice();
            }
        });
        c.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                new Upcoming();
            }
        });
    }
}
