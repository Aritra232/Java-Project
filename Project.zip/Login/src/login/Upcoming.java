/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author HP
 */
public class Upcoming extends JFrame {
    
    Upcoming() {
        JButton back= new JButton("Back");
        back.setBounds(200, 210, 70, 30);
        add(back);
        String data[][] = {{"1.Chess Competition", "5/6/2021", "Room No - 212", "10am-1pm"},
        {"2.Gaming Competition", "5/6/2021", "Room No - 308", "3pm - 6pm"},
        {"3.Project Display", "7/6/2021", "Room No - 401", "11am - 4pm"},
        {"4.Math Competition", "8/6/2021", "Room No - 120", "10am - 11am"},
        {"5.Project", "9/6/2021", "Room No - 120,121,122", "10am - 4pm"},
        {"6.GK Competition", "soon", "will be informed", "11am - 12 pm"},
        {"6.Art Competition", "soon", "will be informed", "11am - 12 pm"},
        {"Soon","Soon","Soon","Soon"}};
        String column[] = {"Notice", "Date", "Place", "Time"};
        JTable jt = new JTable(data, column);
        jt.setBounds(30, 40, 200, 300);
        JScrollPane sp = new JScrollPane(jt);
        add(sp);
        setSize(500, 500);
        setVisible(true);
        
        back.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                new Information();
                setVisible(false);
            }
        });

    }

}
