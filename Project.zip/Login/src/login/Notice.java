/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.awt.event.*;
import static javafx.scene.input.KeyCode.J;
import javax.swing.*;
import javax.swing.JLabel;

/**
 *
 * @author HP
 */
public class Notice extends JFrame {

    Notice() {
        JButton back = new JButton("Back");
        back.setBounds(200, 210, 70, 30);
        add(back);
        String data[][] = {{"1.Orientation", "5/6/2021", "Room No - 212"},
        {"2.Robotics Club Joining Registration", "Soon", "Room No - 307"},
        {"3.Meeting", "7/6/2021", "Room No - 412"},
        {"4.Renew Card", "10/6/2021", "Room No - 121"},
        {"will be informed", "will be informed", "will be informed"}};
        String column[] = {"Notice", "Date", "Place"};

        JTable jt = new JTable(data, column);
        jt.setBounds(150, 160, 200, 300);
        JScrollPane sp = new JScrollPane(jt);

        add(sp);

        setSize(500, 500);
        setVisible(true);

        back.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                new Information();
                setVisible(false);
            }
        });
    }

}
